# NIKKI AI — Android project

A native Android starter app with a dark futuristic UI, chat screen, speech recognition, and text-to-speech.

## Language support
Tap `EN | తెలుగు` in the header to switch the interface and speech recognition between English (UK locale) and Telugu (India locale). The app asks Android's installed speech/TTS services for the selected language. Availability, accent, and voice gender depend on the speech engine and installed voice packs; a British-style male voice is not guaranteed on every phone.

## Important limitations
This version uses demo responses. It is not yet connected to a real AI model. To enable real AI, connect a secure backend. Never embed private API keys in an Android app.

## Build an APK
1. Upload the project files to a GitHub repository, including the hidden `.github` folder.
2. Push to `main` or `master`, or open Actions and run `Build NIKKI AI Android APK`.
3. Download the `NIKKI-AI-debug-APK` artifact from the completed workflow.
4. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask permission to install apps from that source.

You can also open the project in Android Studio and choose Build > Build APK(s). This ZIP is source code, not a compiled APK.
