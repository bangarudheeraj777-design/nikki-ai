package com.example.nikkiai;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 42;
    private LinearLayout messages;
    private ScrollView scroll;
    private EditText input;
    private TextToSpeech tts;
    private boolean telugu = false;
    private TextView languageButton;
    private TextView languageHint;

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 14, 27));
        getWindow().setNavigationBarColor(Color.rgb(5, 14, 27));
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) configureVoice();
        });
        buildUI();
        addMessage("NIKKI", "Hello, boss. I'm online. You can switch between English and Telugu using the language button. This starter version uses demo replies until an AI backend is connected.", false);
    }

    private void configureVoice() {
        Locale locale = telugu ? new Locale("te", "IN") : Locale.UK;
        int result = tts.setLanguage(locale);
        // Android's available voices depend on the installed speech engine and voice packs.
        // Prefer a voice tagged as male if the engine provides gender metadata; otherwise use its locale default.
        try {
            Set<Voice> voices = tts.getVoices();
            if (voices != null) {
                Voice chosen = null;
                for (Voice voice : voices) {
                    if (!voice.getLocale().getLanguage().equals(locale.getLanguage())) continue;
                    String name = voice.getName().toLowerCase(Locale.ROOT);
                    if (name.contains("male") || name.contains("man")) { chosen = voice; break; }
                    if (chosen == null && !voice.isNetworkConnectionRequired()) chosen = voice;
                }
                if (chosen != null) tts.setVoice(chosen);
            }
        } catch (Exception ignored) {}
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(12));
        root.setBackgroundColor(Color.rgb(5, 14, 27));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = new TextView(this);
        logo.setText("N");
        logo.setTextColor(Color.rgb(82, 225, 255));
        logo.setTextSize(25);
        logo.setTypeface(null, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(bg(Color.rgb(11, 31, 49), 13, Color.rgb(49, 160, 190)));
        header.addView(logo, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        TextView title = new TextView(this);
        title.setText("NIKKI AI");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(null, Typeface.BOLD);
        TextView subtitle = new TextView(this);
        subtitle.setText("PERSONAL INTELLIGENCE");
        subtitle.setTextColor(Color.rgb(102, 190, 211));
        subtitle.setTextSize(10);
        titles.addView(title);
        titles.addView(subtitle);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));

        languageButton = new TextView(this);
        languageButton.setText("EN | తెలుగు");
        languageButton.setTextColor(Color.rgb(95, 226, 255));
        languageButton.setTextSize(12);
        languageButton.setGravity(Gravity.CENTER);
        languageButton.setPadding(dp(10), dp(9), dp(10), dp(9));
        languageButton.setBackground(bg(Color.rgb(15, 39, 59), 10, Color.rgb(35, 78, 103)));
        languageButton.setOnClickListener(v -> toggleLanguage());
        header.addView(languageButton);
        root.addView(header);

        TextView hero = new TextView(this);
        hero.setText("\n◉\n\n" + (telugu ? "బాస్, నేను ఎలా సహాయం చేయగలను?" : "HOW CAN I HELP, BOSS?"));
        hero.setTextColor(Color.rgb(89, 225, 255));
        hero.setTextSize(18);
        hero.setTypeface(null, Typeface.BOLD);
        hero.setGravity(Gravity.CENTER);
        hero.setPadding(0, dp(20), 0, dp(18));
        root.addView(hero);

        languageHint = new TextView(this);
        languageHint.setText(telugu ? "తెలుగు మోడ్" : "ENGLISH MODE • BRITISH-STYLE VOICE IF AVAILABLE");
        languageHint.setTextColor(Color.rgb(102, 151, 177));
        languageHint.setTextSize(10);
        languageHint.setGravity(Gravity.CENTER);
        languageHint.setPadding(0, 0, 0, dp(8));
        root.addView(languageHint);

        scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setBackground(bg(Color.rgb(9, 25, 41), 16, Color.rgb(24, 56, 79)));
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(dp(12), dp(12), dp(12), dp(12));
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(dp(8), dp(6), dp(6), dp(6));
        composer.setBackground(bg(Color.rgb(9, 23, 38), 14, Color.rgb(29, 65, 88)));
        LinearLayout.LayoutParams composerParams = new LinearLayout.LayoutParams(-1, -2);
        composerParams.topMargin = dp(12);
        input = new EditText(this);
        input.setSingleLine(false);
        input.setMaxLines(3);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.rgb(113, 143, 165));
        input.setHint(telugu ? "నిక్కీకి సందేశం పంపండి..." : "Message NIKKI...");
        input.setTextSize(15);
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        composer.addView(input, new LinearLayout.LayoutParams(0, -2, 1));

        Button mic = makeButton("🎙", false);
        composer.addView(mic, new LinearLayout.LayoutParams(dp(48), dp(46)));
        mic.setOnClickListener(v -> startVoice());

        Button send = makeButton("➤", true);
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(48), dp(46));
        sendParams.leftMargin = dp(6);
        composer.addView(send, sendParams);
        send.setOnClickListener(v -> sendMessage());
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendMessage(); return true; }
            return false;
        });
        root.addView(composer, composerParams);

        TextView foot = new TextView(this);
        foot.setText(telugu ? "నిక్కీ సమాధానాన్ని వినడానికి దానిపై ట్యాప్ చేయండి" : "Tap a NIKKI reply to hear it spoken");
        foot.setTextColor(Color.rgb(91, 119, 141));
        foot.setTextSize(10);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(10), 0, 0);
        root.addView(foot);
        setContentView(root);
    }

    private Button makeButton(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(primary ? 20 : 17);
        b.setAllCaps(false);
        b.setTextColor(primary ? Color.rgb(3, 18, 31) : Color.rgb(95, 226, 255));
        b.setPadding(0, 0, 0, 0);
        b.setBackground(bg(primary ? Color.rgb(75, 210, 255) : Color.rgb(15, 39, 59), 12,
                primary ? 0 : Color.rgb(35, 78, 103)));
        return b;
    }

    private void toggleLanguage() {
        telugu = !telugu;
        configureVoice();
        // Rebuild the shell to update prompts and labels; keep a language confirmation in the conversation.
        String oldInput = input.getText().toString();
        buildUI();
        input.setText(oldInput);
        addMessage("NIKKI", telugu ? "తెలుగు మోడ్ ప్రారంభించబడింది, బాస్." : "English mode activated, boss.", false);
    }

    private void addMessage(String sender, String text, boolean user) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(dp(10), dp(9), dp(10), dp(9));
        item.setBackground(bg(user ? Color.rgb(17, 46, 76) : Color.rgb(14, 35, 54), 12,
                user ? Color.rgb(42, 80, 124) : Color.rgb(26, 61, 83)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(10);
        item.setLayoutParams(params);

        TextView label = new TextView(this);
        label.setText(sender);
        label.setTextColor(user ? Color.rgb(166, 197, 255) : Color.rgb(89, 225, 255));
        label.setTextSize(10);
        label.setTypeface(null, Typeface.BOLD);
        TextView body = new TextView(this);
        body.setText(text);
        body.setTextColor(Color.rgb(234, 245, 255));
        body.setTextSize(14);
        body.setPadding(0, dp(5), 0, 0);
        item.addView(label);
        item.addView(body);
        if (!user) item.setOnClickListener(v -> speak(text));
        messages.addView(item);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void sendMessage() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        input.setText("");
        addMessage(telugu ? "మీరు" : "YOU", text, true);
        addMessage("NIKKI", demoAnswer(text), false);
    }

    private String demoAnswer(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        if (telugu) {
            if (lower.contains("hello") || lower.contains("హలో") || lower.contains("నమస్కారం"))
                return "నమస్కారం బాస్! నేను నిక్కీ. నిజమైన AI సమాధానాల కోసం AI బ్యాకెండ్‌ను కనెక్ట్ చేయాలి.";
            if (lower.contains("ఎవరు") || lower.contains("పరిచయం"))
                return "నేను నిక్కీ, మీ వ్యక్తిగత AI అసిస్టెంట్ యాప్. నేను వాయిస్ ఇన్‌పుట్ మరియు మాటల రూపంలో సమాధానాలు ఇవ్వగలను. పూర్తి AI కోసం బ్యాకెండ్ అవసరం.";
            if (lower.contains("ai") || lower.contains("కృత్రిమ మేధ"))
                return "కృత్రిమ మేధ (AI) అనేది భాషను అర్థం చేసుకోవడం, నమూనాలను గుర్తించడం, సమస్యలను పరిష్కరించడం వంటి పనుల్లో కంప్యూటర్లకు సహాయపడే సాంకేతికత.";
            return "మీ సందేశం అందింది బాస్. ఇది ప్రారంభ వెర్షన్ కాబట్టి ప్రస్తుతం నమూనా సమాధానాలు మాత్రమే ఇస్తుంది. పూర్తి AI కోసం మోడల్‌ను కనెక్ట్ చేయాలి.";
        } else {
            if (lower.contains("hello") || lower.equals("hi"))
                return "Hello, boss. I'm ready to help. Connect an AI backend for real AI-generated answers.";
            if (lower.contains("who are you") || lower.contains("introduce"))
                return "I am NIKKI, your personal assistant app. I support text, Android speech recognition, and spoken replies. My full AI brain needs to be connected next.";
            if (lower.contains("ai"))
                return "Artificial intelligence helps computers perform tasks such as understanding language, recognizing patterns, and solving problems. Connect an AI backend for open-ended AI conversations.";
            return "Message received, boss. This version uses demo replies, not a full AI model yet. The next step is connecting NIKKI to a secure AI backend.";
        }
    }

    private void startVoice() {
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, telugu ? "te-IN" : "en-GB");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, telugu ? "నిక్కీతో మాట్లాడండి" : "Speak to NIKKI");
            startActivityForResult(intent, SPEECH_REQUEST);
        } catch (Exception e) {
            Toast.makeText(this, "Speech recognition isn't available on this device.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                input.setText(results.get(0));
                input.setSelection(input.length());
            }
        }
    }

    private void speak(String text) {
        if (tts != null) {
            configureVoice();
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nikki_reply");
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
